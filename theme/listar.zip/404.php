<?php get_header(); ?>
    <div class="container page-404">
        <div class="title-404 text-center">Page Not Found</div>
        <div class="content-404 text-center">
            We’re sorry, but the page you were looking for doesn’t exist
        </div>
        <div class="btn-back-404">
            <a href="<?php echo home_url();?>" class="btn btn-primary btn-lg btn-block">
                <i class="fas fa-angle-left text-left"></i> Back Home
            </a>
        </div>
    </div>
<?php get_footer(); ?>