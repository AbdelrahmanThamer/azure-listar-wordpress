    </main>
    <footer class="footer">
        <div class="container">
            <div class='row'>
                <div class='footer-info'>
                    <h5 class="title"><?php echo get_option('blogname')?></h5>
                    <p class="desc"><?php echo get_option('blogdescription')?></p>
                    <div class="d-flex mg-b-15">
                        <div class="pd-r-20">
                            <a href="<?php echo listar_theme_option('url_ios') ? esc_attr(listar_theme_option('url_ios')) : '#'; ?>" target="_blank">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/app-store-big.png">
                            </a>
                        </div>
                        <div class="">
                            <a href="<?php echo listar_theme_option('url_android') ? esc_attr(listar_theme_option('url_android')) : '#'; ?>" target="_blank">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/google-play-big.png">
                            </a>
                        </div>
                    </div>
                    <div class="icons-list d-flex justify-content-between mg-b-15">
                        <?php
                            $social_network = [
                                [
                                    'icon' => 'fa-facebook',
                                    'url' => esc_attr(listar_theme_option('url_facebook'))
                                ],
                                [
                                    'icon' => 'fa-instagram',
                                    'url' => esc_attr(listar_theme_option('url_instagram'))
                                ],
                                [
                                    'icon' => 'fa-youtube',
                                    'url' => esc_attr(listar_theme_option('url_youtube'))
                                ],
                                [
                                    'icon' => 'fa-pinterest',
                                    'url' => esc_attr(listar_theme_option('url_instagram'))
                                ],
                                [
                                    'icon' => 'fa-twitter',
                                    'url' => esc_attr(listar_theme_option('url_twitter'))
                                ]
                            ]
                        ?>
                        <ul class="social-network">
                            <?php foreach($social_network as $item) {
                                if($item['url']) {
                                    echo '<li><a href="'.$item['url'].'"><i class="fab '.$item['icon'].'"></i></a></li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
                <div class='footer-info'>
                    <?php
                    $menu_id = 'footer-menu-col-2';
                    if(has_nav_menu($menu_id)) {
                        $menu_obj = listar_get_menu_by_location($menu_id);
                        echo '<h5 class="title">'.$menu_obj->name.'</h5>';
                        wp_nav_menu([
                            'theme_location' => $menu_id,
                            'menu_class' => 'nav-list list-unstyled',
                            'container_class' => 'contact-info',
                            'walker' => new Listar_Walker_Footer_Menu()
                        ]);
                    }
                    ?>
                </div>
                <div class='footer-info'>
                    <?php
                    $menu_id = 'footer-menu-col-3';
                    if(has_nav_menu($menu_id)) {
                        $menu_obj = listar_get_menu_by_location($menu_id);
                        echo '<h5 class="title">'.$menu_obj->name.'</h5>';
                        wp_nav_menu([
                            'theme_location' => $menu_id,
                            'menu_class' => 'nav-list list-unstyled',
                            'container_class' => 'contact-info',
                            'walker' => new Listar_Walker_Footer_Menu()
                        ]);
                    }
                    ?>
                </div>
                <div class='footer-info'>
                    <h5 class="title">Get In Touch</h5>
                    <div class='contact-info'>
                        <p class="desc"><?php echo esc_attr(listar_theme_option('instruction')) ?></p>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-map-marker-alt"></i><span><?php echo esc_attr(listar_theme_option('address')) ?></span></li>
                            <li><i class="fas fa-phone"></i><span><?php echo esc_attr(listar_theme_option('phone')) ?></span></li>
                            <li><i class="fas fa-envelope"></i><span><?php echo esc_attr(listar_theme_option('email')) ?></span></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="copyright justify-content-between">
                <div>
                    <?php echo esc_attr(listar_theme_option('copyright')) ?>
                </div>
            </div>
        </div>
    </footer>
    <div id='under-background'></div>
    <div id='under-background-setting'></div>

    <?php wp_footer(); ?>
</body>
</html>