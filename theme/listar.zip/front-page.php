<?php get_header(); ?>
<div class="listar-background">
    <?php if(get_header_image()) { ?>
        <img src="<?php header_image(); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
    <?php } else { ?>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/header-image.jpg" />
    <?php } ?>
    <div class="search">
        <?php get_search_form(); ?>
    </div>
</div>

<div>
    <?php if ( is_active_sidebar( 'listar-home-sidebar' ) ) { ?>
        <?php dynamic_sidebar( 'listar-home-sidebar' ); ?>
    <?php } else { ?>
        <!-- Default sidebar/content -->
    <?php } ?>
</div>
<?php get_footer(); ?>
