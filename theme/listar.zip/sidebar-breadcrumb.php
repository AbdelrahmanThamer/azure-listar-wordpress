<?php
$delimiter = '';
$home = _('Home');
$home_link = home_url();
$before = '<li class="breadcrumb-item">';
$after = '</li>';
if(!is_home() && !is_front_page()) {
?>
<div class="container container-breadcrumb">
    <ul class="breadcrumb pd-t-15 pd-b-5">
        <li class="breadcrumb-item "><a href="<?php echo esc_attr($home_link);?>"><?php echo esc_attr($home);?></a> </li>
        <?php if ( !is_home() && !is_front_page() || is_paged() ) {
            if(is_archive()) {
                if ( get_post_type() === Listar_Theme::$post_type ) {
                    echo html_entity_decode(esc_html($before . __('Listing', 'listar_wp') . $after));
                }
            } else if ( is_category() ) {
                echo html_entity_decode(esc_html($before . single_cat_title('', false) . $after));
            } elseif ( is_day() ) {
                echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
                echo '<a href="' . get_month_link(get_the_time('Y'),get_the_time('m')) . '">' . get_the_time('F') . '</a> ' . $delimiter . ' ';
                echo html_entity_decode(esc_html($before . get_the_time('d') . $after));
            } elseif ( is_month() ) {
                echo '<a href="' . get_year_link(get_the_time('Y')) . '">' . get_the_time('Y') . '</a> ' . $delimiter . ' ';
                echo html_entity_decode(esc_html($before . get_the_time('F') . $after));
            } elseif ( is_year() ) {
                echo html_entity_decode(esc_html($before . get_the_time('Y') . $after));
            } elseif ( is_single() && !is_attachment() ) {
                $items = [];
                if ( get_post_type() === Listar_Theme::$post_type ) {
                    $categories = get_the_category();
                    $first_category = array_shift($categories);

                    if($first_category) {
                        $items[] = [
                            'link' => $home_link.'/'.$first_category->slug,
                            'label' => get_category_parents($first_category, TRUE, ' ' . $delimiter . ' ')
                        ];
                    }

                    $items[] = [
                        'link' => NULL,
                        'label' => get_the_title()
                    ];
                } else {
                    $post_type = get_post_type_object(get_post_type());
                    $items = [
                        [
                            'link' => $home_link.'/'.$post_type->rewrite['slug'],
                            'label' => $post_type->labels->singular_name
                        ],
                        [
                            'link' => NULL,
                            'label' => get_the_title()
                        ],
                    ];
                }

                // Render full patch
                foreach($items as $item) {
                    if($item['link']) {
                        echo html_entity_decode(esc_html($before . '<a href="' . $item['link'].'">' . $item['label'] . '</a>' . $after));
                    } else {
                        echo html_entity_decode(esc_html($before . $item['label'] . $after));
                    }
                }
            } elseif ( is_attachment() ) {
                $parent = get_post($post->post_parent);
                $cat = get_the_category($parent->ID); $cat = $cat[0];

                echo get_category_parents($cat, TRUE, ' ' . $delimiter . ' ');
                echo '<a href="' . get_permalink($parent) . '">' . $parent->post_title . '</a> ' . $delimiter . ' ';
                echo html_entity_decode(esc_html($before . get_the_title() . $after));
            } elseif ( is_page() && !$post->post_parent ) {
                echo html_entity_decode(esc_html($before . get_the_title() . $after));
            } elseif ( is_page() && $post->post_parent ) {
                $parent_id = $post->post_parent;
                $breadcrumbs = array();

                while ($parent_id) {
                    $page = get_page($parent_id);
                    $breadcrumbs[] = '<a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a>';
                    $parent_id = $page->post_parent;
                }

                $breadcrumbs = array_reverse($breadcrumbs);

                foreach ($breadcrumbs as $crumb) {
                    echo html_entity_decode(esc_html($crumb . ' ' . $delimiter . ' '));
                }

                echo html_entity_decode(esc_html($before . get_the_title() . $after));
            } elseif ( is_search() ) {
                echo html_entity_decode(esc_html($before . __('Search results for  ', 'listar_wp') . '"' . get_search_query() . '"' . $after));
            } elseif ( is_tag() ) {
                echo html_entity_decode(esc_html($before . __('Posts tagged ', 'listar_wp') . '"' . single_tag_title('', false) . '"' . $after));
            } elseif ( is_author() ) {
                global $author;
                echo html_entity_decode(esc_html($before . __('Articles posted by ', 'listar_wp') . __('Anonymouse', 'listar_wp') . $after));
            } elseif ( is_404() ) {
                echo html_entity_decode(esc_html($before . __('Error 404', 'listar_wp') . $after));
            }

            // Pagination
            if ( get_query_var('paged') ) {
                if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ' (';
                echo html_entity_decode(esc_html($before . __('Page', 'listar_wp') . ' ' . get_query_var('paged') . $after));
                if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() ) echo ')';
            }
        } ?>
    </ul>
</div>
<?php } ?>