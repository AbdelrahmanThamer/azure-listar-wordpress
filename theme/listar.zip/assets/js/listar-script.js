$('.noUi-handle').on('click', function () {
  $(this).width(50);
});

function create_slider_range(item_range, callBack) {
  var minmax = $(item_range).data('minmax');
  if (typeof (minmax) != undefined) {
    var arrayMinMax = minmax.split("-");
    if (arrayMinMax.length == 2) {
      var init = $(item_range).data('init');
      var step = $(item_range).data('step') ? parseInt($(item_range).data('step')) : 1;
      var arrayInit = init.split("-");
      var rangeSlider = document.createElement("div");

      noUiSlider.create(rangeSlider, {
        start: [parseInt(arrayInit[0]), parseInt(arrayInit[1])],
        step: step,
        range: {
          'min': [parseInt(arrayMinMax[0])],
          'max': [parseInt(arrayMinMax[1])]
        },
        format: wNumb({ decimals: 0, thousand: ',' }),
        connect: true
      });

      $(item_range).append(rangeSlider);
      rangeSlider.noUiSlider.on('update', function (values, handle) {
        callBack(values[0], values[1]);
      });
    }
  }
}

$(function() {
  var $window = $(window);

  $window.resize(function resize() {
    if ($window.width() < 1200) {
      $('.grid-sub').addClass('off-canvas off-canvas-overlay off-canvas-left');
    } else {
      $('.grid-sub').removeClass('off-canvas off-canvas-overlay off-canvas-left');
    }
  }).trigger('resize');

  $('.nav-sub-link').on('click', function (e) {
    e.preventDefault();
    document.location.href = $(this).attr('href');
  });

  if (typeof (Storage) == 'undefined' || sessionStorage.getItem("mode-theme") == null || php_value.control == '') {
    sessionStorage.setItem("mode-theme", php_value.theme);
  }
  var mode = sessionStorage.getItem("mode-theme");
  document.body.setAttribute('data-theme', mode);

  $('#themeSwitch').on('change', function() {
    if($('#themeSwitch').is(':checked')) {
      document.body.setAttribute('data-theme', 'dark');
    } else {
      document.body.setAttribute('data-theme', 'light');
    }
  });

  if (typeof (Storage) == 'undefined' || sessionStorage.getItem("mode-color") == null || php_value.control == '') {
    sessionStorage.setItem("mode-color", php_value.color);
  }
  document.body.setAttribute('class', sessionStorage.getItem("mode-color"));
  activeModeColor(sessionStorage.getItem("mode-color"));

  $('.off-canvas-menu').on('click', function (e) {
    e.preventDefault();
    var target = $(this).attr('href');
    $(target).addClass('show');
  });

  $('.off-canvas .close').on('click', function (e) {
    e.preventDefault();
    $(this).closest('.off-canvas').removeClass('show');
  })
  $(document).on('click touchstart', function (e) {
    e.stopPropagation();

    if (!$(e.target).closest('.off-canvas-menu').length) {
      var offCanvas = $(e.target).closest('.off-canvas').length;
      if (!offCanvas) {
        $('.off-canvas.show').removeClass('show');
      }
    }

    if (!$(e.target).closest('.nav-item.with-sub').length) {
      var offCanvas = $(e.target).closest('.nav-item').length;
      if (!offCanvas) {
        $('.nav-item.with-sub.show').removeClass('show');
      }
    }
  });

  $(".off-canvas-content").append("<div class='backdrop'></div>");
  $('#mainMenuOpen').on('click', function (e) {
    e.preventDefault();
    var body = document.body;
    body.classList.add("navbar-nav-show");
  });

  $('#mainMenuClose').on('click', function (e) {
    e.preventDefault();
    var body = document.body;
    body.classList.remove("navbar-nav-show");
  });

  $('.backdrop-main-menu').on('click', function (e) {
    e.preventDefault();
    var body = document.body;
    body.classList.remove("navbar-nav-show");
  });

  $('.nav-item.with-sub').on('click', function (e) {
    e.preventDefault();
    $(this).toggleClass('show');
  });

  $('.off-canvas .close').on('click', function (e) {
    e.preventDefault();
    $(this).closest('.off-canvas').removeClass('show');
  });
});

var inputSearch = document.getElementsByClassName("search-input");
for (var i = 0; i < inputSearch.length; i++) {
  inputSearch[i].addEventListener('click', function (e) {
    if (e.offsetX > this.offsetWidth) {
      console.log('aaaaa')
    } else {
      $(this).find('input').val('');
    }
  });
}

function chooseModeColor(color) {
  document.body.setAttribute('class', color);
  sessionStorage.setItem("mode-color", color);
  activeModeColor(color);
}

function activeModeColor(color) {
  $('.ls-mode').each(function (e) {
    const nodeColor = $(this).data('color');
    if (color === nodeColor)
      $(this).addClass('active');
    else
      $(this).removeClass('active');
  });
}

//### Add for temp
jQuery(document).ready(function ($) {
  $('#images_gallery').lightSlider({
    gallery: true,
    item: 1,
    loop: true,
    thumbItem: 9,
    slideMargin: 0,
    enableDrag: false,
    currentPagerPosition: 'left',
    onSliderLoad: function (el) {
    }
  });
});