<?php
get_header();

if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
        if (get_post_type() === Listar_Theme::$post_type) {
            get_template_part('template-parts/listar/content', 'single');
        } else {
            get_template_part('template-parts/post/content');
        }
    }
}
get_footer();