<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php wp_head(); ?>
</head>
<body data-theme="<?php echo listar_theme_option('dark_mode');?>" class="<?php echo listar_theme_option('skin');?>" <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <header class="navbar navbar-header navbar-header-fixed">
        <div class="container">
            <a href="#" id="mainMenuOpen" class="burger-menu">
                <i class="fas fa-bars"></i>
            </a>
            <a class="navbar-brand" href="<?php echo home_url();?>">
                <?php
                    if(has_custom_logo()) {
                        $custom_logo_id = get_theme_mod('custom_logo');
                        $logo = wp_get_attachment_image_src($custom_logo_id);

                        echo '<img src="' . $logo[0] . '" class="rounded-circle">';
                    } else {
                        $logo = get_template_directory_uri() . '/assets/img/icon_40pt.png';
                        echo '<img src="' . $logo . '" class="rounded-circle">';
                    }
                ?>

                <span><?php echo get_bloginfo('name') ? get_bloginfo('name') : "Directory Listing"; ?></span>
            </a>
            <div id="navbarMenu" class="navbar-menu-wrapper">
                <div class="navbar-menu-header">
                    <a href="<?php echo home_url();?>">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon_40pt.png" class="rounded-circle">
                        <span>Directory Listing</span>
                    </a>
                    <a href="#" id="mainMenuClose" class="close"><i class="fas fa-times"></i></a>
                </div>
                <?php
                /**
                 * Header menu
                 * - Check from class Listar_WP->register_nav_menus()
                 */
                 if ( has_nav_menu( 'header-menu' )) {
                     wp_nav_menu(
                         [
                             'theme_location' => 'header-menu',
                             'container' => '',
                             'menu_class' => 'nav navbar-menu',
                             'walker' => new Listar_Walker_Nav_Menu()
                         ]
                     );
                 }
                ?>
            </div>
            <div class="navbar-right"></div>
        </div>
        <!-- Skin controller -->
        <?php if(listar_theme_option('skin_control')) { ?>
        <a class='setting-mode-color bg-primary off-canvas-menu' href="#offCanvasTheme">
            <img src='<?php echo get_template_directory_uri(); ?>/assets/img/setting-loading-2.gif' />
        </a>
        <div class="off-canvas-content">
            <div class="off-canvas off-canvas-overlay off-canvas-right setting-theme" id='offCanvasTheme'>
                <div class='title bd-b d-flex align-items-center justify-content-between'>
                    <span class='customizer'><?php _e('Settings', 'listar_wp');?></span>
                    <a href="#" class="close"><i class="fas fa-times"></i></a>
                </div>
                <div class='setting-theme'>
                    <div class='darkmode d-flex justify-content-between align-items-center'>
                        <span class='setting-title'><?php _e('Darkmode', 'listar_wp');?></span>
                        <label class="switch">
                            <input type="checkbox" id='themeSwitch' onchange="themeSwitch()">
                            <span class="slider round bg-primary"></span>
                        </label>
                    </div>
                    <div class='theme-color'>
                        <div class='setting-title'><?php __('Color', 'listar_wp');?></div>
                        <div class='container-mode-color'>
                            <a class='ls-mode' data-color="orange-skin" onclick="chooseModeColor('orange-skin')" style="background: #e5634d">
                                <?php _e('Orange', 'listar_wp');?>
                            </a>
                            <a class='ls-mode' data-color="lightblue-skin" onclick="chooseModeColor('lightblue-skin')" style="background: #23b0e8">
                                <?php _e('Lightblue', 'listar_wp');?>
                            </a>
                            <a class='ls-mode' data-color="pink-skin" onclick="chooseModeColor('pink-skin')" style="background: #e91e63">
                                <?php _e('Pink', 'listar_wp');?>
                            </a>
                            <a class='ls-mode' data-color="green-skin" onclick="chooseModeColor('green-skin')" style="background: #4caf50">
                                <?php _e('Green', 'listar_wp');?>
                            </a>
                            <a class='ls-mode' data-color="yellow-skin" onclick="chooseModeColor('yellow-skin')" style="background: #ffc107">
                                <?php _e('Yellow', 'listar_wp');?>
                            </a>
                            <a class='ls-mode' data-color="blue-skin" onclick="chooseModeColor('blue-skin')" style="background: #206ab0">
                                <?php _e('Blue', 'listar_wp');?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </header>
    <div class='backdrop backdrop-main-menu'></div>
    <main class="content content-fixed <?php echo (is_home() || is_front_page()) ? 'home-page' : 'home-page-2';?>">
    <!-- Breadcrumb !-->
    <?php get_sidebar('breadcrumb');?>