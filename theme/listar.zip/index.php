<?php
get_header();
get_template_part('template-parts/post/archive');
get_footer();
?>