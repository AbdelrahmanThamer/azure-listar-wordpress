<!--
    The template for displaying comments. The area of the page that contains both current comments and the comment form.
    @author Listar
-->
<?php
if (post_password_required()) {
    return;
}
?>

<?php if (have_comments()) : ?>
    <div class="title-section mg-t-30 mg-b-30">
        <?php _e('Reviews', 'listar_wp');?>
    </div>
    <ul class="list-unstyled">
        <?php
        function format_comment($comment, $args, $depth) {
            $GLOBALS['comment'] = $comment; ?>

            <li class="mg-b-10 comment-item" id="listar-comment-<?php comment_ID() ?>">
                <div class="d-flex justify-content-between align-items-center ht-60 author">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/profile-1.jpg">
                    <div class="flex-grow-1 mg-l-5">
                        <div class="author-name"><?php echo get_comment_author(); ?></div>
                        <?php
                        $rate = get_comment_meta($comment->comment_ID, 'rating');
                        if($rate) {
                            listar_the_rating_icon(5, true, $rate[0]);
                        }
                        ?>
                    </div>
                    <span class="sub-desc"><?php sprintf('%2$s - %1$s', get_comment_date(), get_comment_time()); ?></span>
                </div>
                <?php if ($comment->comment_approved == '0') : ?>
                    <em>
                        <?php _e('Your comment is awaiting moderation.', 'listar_wp'); ?>
                    </em>
                    <br/>
                <?php endif; ?>
                <?php
                comment_text();
                comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth'])));
                ?>
            </li>
        <?php
        }

        wp_list_comments(array(
            'style' => 'ul',
            'short_ping' => true,
            'callback' => 'format_comment'
        ));
        ?>
    </ul>
    <!-- .comment-list -->
    <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
        <nav id="comment-nav-below" class="comment-navigation" role="navigation">
            <h1 class="screen-reader-text"><?php _e('Comment navigation', ''); ?></h1>
            <div class="nav-previous"><?php previous_comments_link(__('&larr; Older Comments', 'listar_wp')); ?></div>
            <div class="nav-next"><?php next_comments_link(__('Newer Comments &rarr;', 'listar_wp')); ?></div>
        </nav>
    <?php endif; ?>
<?php endif; ?>
<!-- have_comments() -->
<?php if (!comments_open() && '0' != get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
    <?php _e('Review is closed.', ''); ?>
<?php endif; ?>
<?php
$fields = array(
    'author' => '<div class="row"><div class="col-md-6 col-sm-12 mg-b-15">' .
        '    <input type="text" class="form-control form-control-lg" id="author" name="author" value="' . esc_attr($commenter['comment_author']) . '" placeholder="Name *" />' .
        '</div>',
    'email'  => '<div class="col-md-6 col-sm-12 mg-b-15">' .
        '    <input type="email" class="form-control form-control-lg" id="email" name="email" value="' . esc_attr($commenter['comment_author_email']) . '" placeholder="Email *" />' .
        '</div></div>',
    'rating' => '',
);
$rating_field = '';
if(get_post_type() === Listar_Theme::$post_type) {
    $rating_field = '<div class="row"><div class="col-md-12 col-sm-12 review-rate">' .
                        '<fieldset class="float-left mr-0 rating">' .
                            '<input type="radio" id="star5" name="rating" value="5" onClick="rateClick(\'5\')" /><label class="full mb-0 mr-0" for="star5" title="Awesome - 5 stars"></label>' .
                            '<input type="radio" id="star4" name="rating" value="4" onClick="rateClick(\'4\')" /><label class="full mb-0" for="star4" title="Pretty good - 4 stars"></label>' .
                            '<input type="radio" id="star3" name="rating" value="3" onClick="rateClick(\'3\')" /><label class="full mb-0" for="star3" title="Meh - 3 stars"></label>' .
                            '<input type="radio" id="star2" name="rating" value="2" onClick="rateClick(\'2\')" /><label class="full mb-0" for="star2" title="Kinda bad - 2 stars"></label>' .
                            '<input type="radio" id="star1" name="rating" value="1" onClick="rateClick(\'1\')" /><label class="full mb-0 ml-0" for="star1" title="Sucks big time - 1 star"></label>' .
                            '<input type="radio" class="reset-option" d="star0" name="rating" value="reset" />' .
                        '</fieldset>' .
                    '</div></div>';
}
$comments_args = array(
    'title_reply'       => '<span class="title-leave-a-comment">'.__('Leave a comment', 'listar_wp').'</span>',
    'title_reply_to'    => __('Reply to %s', 'listar_wp'),
    'cancel_reply_link' => __('Cancel reply', 'listar_wp'),
    'class_submit'      => 'btn btn-primary btn-lg btn-block col-md-6 col-sm-12',
    'label_submit'      => __('Submit', 'listar_wp'),
    'reply_text'        => __('Reply', 'listar_wp'),
    'fields'            => $fields,
    'comment_field'     => $rating_field .
        '<div class="row"><div class="col-md-12 mg-b-15">' .
        '    <textarea class="form-control input-listar" id="comment" name="comment" cols="45" rows="8" aria-required="true" placeholder="'.__('Comment', 'listar_wp').'"></textarea>' .
        '</div></div>',
    'comment_notes_after' => '',
);
?>
<?php comment_form($comments_args); ?>