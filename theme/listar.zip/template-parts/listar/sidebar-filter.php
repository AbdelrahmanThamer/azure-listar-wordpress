<?php
$categories = listar_get_terms('category', ['parent' => 0, 'hide_empty' => 0]);
$features = listar_get_terms('feature', ['parent' => 0, 'hide_empty' => 0]);
$locations = listar_get_terms('location', ['parent' => 0, 'hide_empty' => 0]);
$areas = listar_get_terms('area', ['parent' => 0, 'hide_empty' => 0]);

$category_get = listar_get_request_parameter('category', []);
$feature_get = listar_get_request_parameter('feature', []);

$keyword = listar_get_request_parameter('s');
$category = listar_get_request_parameter('category', []);
$feature = listar_get_request_parameter('feature', []);
$location = listar_get_request_parameter('location', []);
$price_min = listar_get_request_parameter('price_min');
$price_max = listar_get_request_parameter('price_max');
$rating = listar_get_request_parameter('rating');
$sorting = listar_get_request_parameter('sorting');

$price_min_tmp = (int) listar_theme_option('price_min');
$price_max_tmp = (int) listar_theme_option('price_max');
$price_min_init = $price_min ? $price_min : $price_min_tmp + 20;
$price_max_init = $price_max ? $price_max : $price_max_tmp - 20;
?>
<div class="col-md-3 grid-content grid-sub" id="subGrid">
  <form role="search" method="get" action="<?php echo listar_get_listing_url(); ?>"  id="search_form">
    <div class="section-place-filter justify-content-between align-items-center d-flex pd-b-20">
      <div class="grid-title-head flex-grow-1"><?php _e('Searching', 'listar_wp'); ?></div>
      <input type="hidden" name="sorting" value="<?php echo esc_attr($sorting); ?>" />
      <a class="pd-l-5" href="javascript:{}" onclick="document.getElementById('search_form').submit();"><?php _e('Apply', 'listar_wp'); ?></a>
      <a class="pd-l-5 color-custom" href="javascript:{}" onclick="document.getElementById('search_form').reset();"><?php _e('Clear', 'listar_wp'); ?></a>
    </div>
    <div class="section-place-filter">
      <div class="form-group search-input">
        <input type="text" name="s" class="form-control" value="<?php echo esc_attr($keyword); ?>" placeholder="<?php _e('Search', 'listar_wp'); ?>">
      </div>
    </div>
    <div class="section-place-filter">
      <p class="grid-title mg-b-15"><?php _e('Categories', 'listar_wp'); ?></p>
      <?php if (!empty($categories)) { ?>
        <div class="wrapper" style="display: grid;">
          <?php foreach ($categories as $term) { ?>
            <div class="cat-list custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="category-<?php echo esc_attr($term->term_id); ?>" name="category[]" value="<?php echo esc_attr($term->term_id); ?>" <?php echo (is_array($category_get) && in_array($term->term_id, $category_get)) ? 'checked="checked"' : ''; ?> />
              <label class="custom-control-label" for="category-<?php echo esc_attr($term->term_id); ?>"><?php echo esc_attr($term->name); ?></label>
            </div>
          <?php } ?>
          <a class="cat-more" style="cursor: pointer;"><?php _e('More', 'listar_wp'); ?></a>
        </div>
      <?php } ?>
    </div>
    <hr class="pd-t-5" />
    <div class="section-place-filter">
      <p class="grid-title mg-b-15"><?php _e('Facilities', 'listar_wp'); ?></p>
      <?php if (!empty($features)) { ?>
        <div class="wrapper" style="display: grid;">
          <?php foreach ($features as $term) { ?>
            <div class="fac-list custom-control custom-checkbox">
              <input type="checkbox" class="custom-control-input" id="feature-<?php echo esc_attr($term->term_id); ?>" name="feature[]" value="<?php echo esc_attr($term->term_id); ?>" <?php echo in_array($term->term_id, $feature_get) ? 'checked="checked"' : '' ?> />
              <label class="custom-control-label" for="feature-<?php echo esc_attr($term->term_id); ?>"><?php echo esc_attr($term->name); ?></label>
            </div>
          <?php } ?>
          <a class="fac-more" style="cursor: pointer;"><?php _e('More', 'listar_wp'); ?></a>
        </div>
      <?php } ?>
    </div>
    <hr class="pd-t-5" />
    <div class="section-place-filter review-rate">
      <p class="grid-title mg-b-6"><?php _e('Locations', 'listar_wp'); ?></p>
      <div class="d-flex custom-multiselect">
        <span class="multiselect-native-select">
          <select id="location-filtering" name="location[]" multiple="multiple">
            <?php foreach ($locations as $loca) { ?>
              <option value="<?php echo esc_attr($loca->term_id); ?>" <?php echo(in_array($loca->term_id, $location) ? 'selected' : ''); ?>><?php echo esc_attr($loca->name); ?></option>
            <?php } ?>
          </select>
        </span>
      </div>
    </div>
    <hr class="pd-t-5" />
    <div class="section-place-filter">
      <p class="grid-title mg-b-15"><?php _e('Price Range', 'listar_wp'); ?></p>
      <div class="price_range">
        <div class="ls-min-max">
          <span>$<?php echo esc_attr($price_min_tmp); ?></span>
          <span>$<?php echo esc_attr($price_max_tmp); ?></span>
        </div>
        <div id="price_range" data-minmax="<?php echo esc_attr($price_min_tmp) . '-' . esc_attr($price_max_tmp); ?>" data-init="<?php echo esc_attr($price_min_init) . '-' . esc_attr($price_max_init); ?>" data-step="1"></div>
        <div class="ls-labels">
          <strong><?php _e('AVG Price', 'listar_wp'); ?></strong>
          <div>
            <span id="price_range_start"><?php echo '$' . $price_min_init; ?></span> - <span id="price_range_end"><?php echo '$' . $price_max_init; ?></span>
            <input type="hidden" id="price_min" name="price_min" value="<?php echo esc_attr($price_min); ?>" />
            <input type="hidden" id="price_max" name="price_max" value="<?php echo esc_attr($price_max); ?>" />
          </div>
        </div>
      </div>
    </div>
    <hr />
    <div class="section-place-filter review-rate">
      <p class="grid-title mg-b-15"><?php _e('Rating', 'listar_wp'); ?></p>
      <fieldset class="rating">
        <input type="radio" id="star5" name="rating" value="5" <?php echo esc_attr($rating) === '5' ? 'checked' : ''; ?> /><label class="full" for="star5" title="Awesome - 5 stars"></label>
        <input type="radio" id="star4" name="rating" value="4" <?php echo esc_attr($rating) === '4' ? 'checked' : ''; ?> /><label class="full" for="star4" title="Pretty good - 4 stars"></label>
        <input type="radio" id="star3" name="rating" value="3" <?php echo esc_attr($rating) === '3' ? 'checked' : ''; ?> /><label class="full" for="star3" title="Meh - 3 stars"></label>
        <input type="radio" id="star2" name="rating" value="2" <?php echo esc_attr($rating) === '2' ? 'checked' : ''; ?> /><label class="full" for="star2" title="Kinda bad - 2 stars"></label>
        <input type="radio" id="star1" name="rating" value="1" <?php echo esc_attr($rating) === '1' ? 'checked' : ''; ?> /><label class="full" for="star1" title="Sucks big time - 1 star"></label>
        <input type="radio" class="reset-option" id="star0" name="rating" value="reset" />
      </fieldset>
    </div>
  </form>
</div>