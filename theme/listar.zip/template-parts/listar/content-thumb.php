<div class="d-flex recent-category-item">
    <div class="thumb">
        <div class='gradient'></div>
        <?php if (get_the_post_thumbnail() !== '' ) {
            the_post_thumbnail( 'thumb' );
        }
        ?>
    </div>
    <ul class="recent-catefory list-unstyled mg-l-5 mg-t-0">
        <?php the_title( '<li class="title text-ellipsis pd-b-5">', '</li>' ); ?>
        <?php listar_the_categories_list('<li class="desc text-ellipsis pd-b-10">', '</li>');?>
        <li class="rate d-flex">
            <span class="number-category rate-text badge-primary wd-30 mg-r-5">
                <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_avg', TRUE)) ?>
            </span>
            <?php listar_the_rating_icon();?>
        </li>
    </ul>
</div>