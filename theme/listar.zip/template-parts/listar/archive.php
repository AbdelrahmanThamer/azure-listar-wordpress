<?php
$list_mode = listar_get_request_parameter('view', listar_theme_option('list_mode'));
$sort_option = listar_get_sort_option();
?>

<div class="container content-grid">
    <?php get_template_part('template-parts/listar/sidebar', 'filter'); ?>
    <div class="col-md-9 grid-content grid-main mg-l-20">
        <div class="grid-toolbar d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center" style="flex:1">
                <a class="off-canvas-menu btn-open-grid-sub mg-r-10 btn-filter" href="#subGrid ">
                    <i class="fas fa-filter"></i>
                </a>
                <div class="dropdown">
                    <?php
                        $keyword = listar_get_request_parameter('s');
                        $category = listar_get_request_parameter('category');
                        $feature = listar_get_request_parameter('feature');
                        $location = listar_get_request_parameter('location');
                        $rating = listar_get_request_parameter('rating');
                        $sorting = listar_get_request_parameter('sorting');
                    ?>
                    <form role="search" method="get" action="<?php echo listar_get_listing_url(); ?>"  id="search_form_select">
                        <input type="hidden" name="s" value="<?php echo esc_attr($keyword); ?>" />
                        <input type="hidden" name="category" value="<?php echo esc_attr($category); ?>" />
                        <input type="hidden" name="feature" value="<?php echo esc_attr($feature); ?>" />
                        <input type="hidden" name="loaction" value="<?php echo esc_attr($location); ?>" />
                        <input type="hidden" name="rating" value="<?php echo esc_attr($rating); ?>" />
                        <select class="form-select" id="sorting" name="sorting" onchange="this.form.submit()">
                            <?php
                            foreach ($sort_option as $sort) {
                                echo '<option value="' . $sort['lang_key'] . '"' . ($sorting == $sort['lang_key'] ? ' selected' : '') . '>' . esc_attr($sort['title']) . '</option>';
                            }
                            ?>
                        </select>
                    </form>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <a class="btn-filter" href="<?php echo listar_get_listing_url(['view' => 'block']) ?>">
                    <i class="fas fa-th-large"></i>
                </a>
                <a class="btn-filter mg-l-10" href="<?php echo listar_get_listing_url(['view' => 'grid']) ?>">
                    <i class=" fas fa-th"></i>
                </a>
                <a class="btn-filter mg-l-10" href="<?php echo listar_get_listing_url(['view' => 'list']) ?>">
                    <i class=" fas fa-th-list"></i>
                </a>
            </div>
        </div>
        <?php if (have_posts()) { ?>
            <div class="place-grid">
                <ul class="list-unstyled <?php echo esc_attr($list_mode) . '-view'; ?>">
                    <?php while (have_posts()) { ?>
                        <?php the_post(); ?>
                        <li>
                            <?php get_template_part('template-parts/listar/content', esc_attr($list_mode) ?? 'list'); ?>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        <?php } ?>
    </div>
    <div class="col-md-12 mg-y-15">
        <div class="row float-right">
            <?php
                listar_get_pagination();
            ?>
        </div>
    </div>
</div>
