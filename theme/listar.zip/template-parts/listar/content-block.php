<div class="place-item">
    <div class="thumb">
        <div class="gradient"></div>
        <?php if (get_the_post_thumbnail() !== '' ) {
            the_post_thumbnail( 'medium_large' );
        }
        ?>
        <?php $status =  esc_attr(get_post_meta(get_the_ID(), 'status', TRUE));?>
        <?php if($status) { ?>
            <span class="badge-custom status badge badge-pill badge-primary">
                <?php echo esc_attr($status) ;?>
            </span>
        <?php } ?>
        <div class="heart-top text-white">
            <i class="far fa-heart"></i>
        </div>
        <div class="rate-detail">
            <div class="d-flex">
                <span class="badge-tag-custom number-star bg-primary text-white">
                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_avg', TRUE)) ?>
                </span>
                <div class="rate-info mg-l-10">
                    <span class="status-name text-white"><?php echo __('Vert Good', 'listar_wp')?></span>
                    <?php listar_the_rating_icon();?>
                </div>
            </div>
            <span class="count-view text-white">
                <?php echo esc_attr(get_post_meta(get_the_ID(), 'rating_count', TRUE)).' '.__('Rated', 'listar_wp') ?>
            </span>
        </div>
    </div>
    <div class="place-infor">
        <div class="d-flex flex-column place-block">
            <?php listar_the_categories_list('<span class="category text-ellipsis text-bold">', '</span>');?>
            <?php the_title( '<a class="text-dark-blue" href="' . esc_url( get_permalink() ) . '" rel="bookmark"><span class="title text-ellipsis">', '</span></a>' ); ?>
            <ul class="mg-t-10 list-unstyled">
                <li class="place-caption"></li>
                <li class="info text-ellipsis d-flex">
                    <div class="wd-20">
                        <i class="fas fa-map-marker-alt text-default-primary"></i>
                    </div>
                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'address', TRUE)) ?>
                </li>
                <li class="info text-ellipsis d-flex">
                    <div class="wd-20">
                        <i class="fas fa-phone text-default-primary"></i>
                    </div>
                    <?php echo esc_attr(get_post_meta(get_the_ID(), 'phone', TRUE)) ?>
                </li>
                <li class="sub-desc text-ellipsis"></li>
            </ul>
        </div>
    </div>
</div>