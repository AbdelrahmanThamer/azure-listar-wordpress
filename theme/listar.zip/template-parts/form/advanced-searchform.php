<?php
$keyword = listar_get_request_parameter('s');
$category = listar_get_request_parameter('category');
?>

<form class="search" role="search" method="get" action="<?php echo listar_get_listing_url(); ?>">
  <input type="text" class="form-control" name="s" placeholder="<?php _e('What’s are you searching for?', 'listar_wp'); ?>" value="<?php echo esc_attr($keyword); ?>" />
  <div class="dropdown">
    <select class="form-select dropdown-toggle bd-0 btn-dropdown" name="category">
      <?php
      $categories = get_terms(Listar_Theme::$post_type . '_category', [
        'parent' => 0,
        'hide_empty' => 0
      ]);
      echo '<option value="0">'.__('Select', 'listar_wp').'</option>';
      if (!empty($categories)) {
        foreach ($categories as $term) {
          echo '<option value="' . $term->term_id . '" ' . ($term->term_id == $category ? 'selected ' : '') . '>' . esc_attr($term->name) . '</option>';
        }
      }
      ?>
    </select>
  </div>
  <button type="submit" class="btn btn-primary btn-search ">
    <?php _e('Search', 'listar_wp'); ?>
  </button>
</form>