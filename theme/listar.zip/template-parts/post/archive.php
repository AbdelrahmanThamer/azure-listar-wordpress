<div class="row">
    <div class="listar-background">
        <?php echo(get_the_post_thumbnail(get_option('page_for_posts'))); ?>
        <div class="listar-title text-white"><?php _e('Blogs', 'listar_wp');?></div>
    </div>
</div>
<div class="container content-grid mg-t-20">
    <div class="col-md-3 grid-content grid-sub" id="subGrid">
        <?php if ( is_active_sidebar( 'listar-left-sidebar' ) ) { ?>
            <?php dynamic_sidebar( 'listar-left-sidebar' ); ?>
        <?php } else { ?>
            <!-- Default sidebar/content -->
        <?php } ?>
    </div>
    <div class="col-md-9 grid-content grid-main mg-l-20">
        <!-- Mobile menu -->
        <div class="grid-toolbar d-flex justify-content-between align-items-center toolbar-category">
            <div class="d-flex align-items-center" style="flex:1">
                <a class="off-canvas-menu btn-open-grid-sub mg-r-10 btn-filter" href="#subGrid ">
                    <i class="fas fa-th-list"></i>
                </a>
            </div>
        </div>
        <?php if(have_posts()) { ?>
            <div class="blog-grid">
                <ul class="list-unstyled list-view">
                    <?php
                    while(have_posts()) {
                        the_post();
                        get_template_part('template-parts/post/content', 'excerpt');
                    }
                    ?>
                </ul>
            </div>
        <?php } ?>
    </div>
    <div class="col-md-12 mg-y-15">
        <div class="row float-right">
            <?php listar_get_pagination(); ?>
        </div>
    </div>
</div>
