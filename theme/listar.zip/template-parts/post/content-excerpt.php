<li>
    <div class="d-flex place-item">
        <div class="thumb">
            <div class="gradient"></div>
            <span class="badge-custom status badge badge-pill badge-primary"></span>
            <?php
            if (get_the_post_thumbnail() !== '') {
                the_post_thumbnail('thumb');
            }
            ?>
        </div>
        <div class="place-info-blog-list">
            <div class="blog-list d-flex flex-column">
                <span class="category pd-b-10">
                <?php echo get_the_category_list( __(', ', 'listar_wp') ); ?>
                </span>
                <span class="title pd-b-5">
                    <?php the_title('<a href="' . esc_url(get_permalink()) . '">', '</a>'); ?>
                </span>
                <span class="date pd-b-10"><?php echo get_the_date(); ?></span>
                <?php if(false) { ?>
                <span class="sub-desc pd-b-10"></span>
                <span class="sub-desc pd-b-10"></span>
                <?php } ?>
                <span class="desc text-color-main">
                    <?php echo get_the_excerpt_custom(200, 'content'); ?>
                </span>
            </div>
        </div>
        <div class="blog-read-more">
            <a href="<?php echo esc_url( get_permalink());?>"><?php _e('Read more', 'listar_wp');?></a>
        </div>
    </div>
</li>