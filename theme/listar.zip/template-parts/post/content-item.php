<div class="card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="blogs-item">
        <?php if (get_the_post_thumbnail() !== '' ) {
            the_post_thumbnail( 'medium' );
        }
        ?>
        <div class="gradient"></div>
        <div class="item-background-info">
            <div class="date">
                <?php the_date();?>
            </div>
            <div class="pd-b-10">
                <a class="title text-white" href="<?php echo esc_url( get_permalink());?>">
                    <?php the_title() ;?>
                </a>
            </div>
            <div class="desc">
                <?php the_excerpt()?>
            </div>
        </div>
    </div>
</div>